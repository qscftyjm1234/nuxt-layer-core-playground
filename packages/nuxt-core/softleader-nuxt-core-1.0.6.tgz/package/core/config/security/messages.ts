/**
 * 資安提示訊息統一管理
 * @description 集中管理所有資安相關的 UI 提示文字
 */

/**
 * 模糊層訊息介面
 */
export interface BlurMessage {
  /** 圖示 emoji */
  icon: string
  /** 標題文字 */
  title: string
  /** 訊息內容 */
  message: string
  /** 動作提示 */
  action: string
}

/**
 * 資安提示訊息設定
 */
export const securityMessages = {
  /** 截圖偵測提示 */
  screenshot: {
    icon: '⚠️',
    title: '富邦人壽資訊安全提醒',
    message: '為保護客戶資料安全,畫面擷取功能已被限制',
    action: '點擊任意處繼續'
  } as BlurMessage,

  /** 視窗失焦提示 */
  visibility: {
    icon: '⚠️',
    title: '富邦人壽資訊安全提醒',
    message: '為保護客戶資料安全,畫面擷取功能已被限制',
    action: ''
  } as BlurMessage,

  /** 閒置超時提示 */
  idle: {
    icon: '🔒',
    title: '畫面已鎖定',
    message: '因閒置過久,畫面已自動鎖定以保護資料安全',
    action: '點擊任意處或按任意鍵解除鎖定'
  } as BlurMessage
}
